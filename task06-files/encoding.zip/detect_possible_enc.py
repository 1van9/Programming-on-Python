#detect possible encoding for file 
file_name = "ar1.txt"  # you can check for any file

enc = ["utf-8", "utf-32", "koi8-r", "cp1251", "cp1252", "cp1256", "GBK", "latin-1"]
with open(file_name, "r", encoding="utf-8") as f:
    s = f.read()
for e in enc:
    with open("out.txt", "w", encoding=e) as g:
        try:
            g.write(s)
            print(e, "Ok", sep = "\t")
        except:
            print(e, "Fail", sep = "\t")